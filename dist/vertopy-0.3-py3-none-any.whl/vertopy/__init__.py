
from .fungsi_berat import berat

from .fungsi_kecepatan import kecepatan

from .fungsi_waktu import konversi_waktu_satuan

from .fungsi_suhu import suhu

from .fungsi_panjang import panjang
